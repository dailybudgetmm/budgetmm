# My Daily Budget

A full-stack daily income and expense tracking web application designed for Myanmar users.

## Tech Stack

- **Frontend**: React + TypeScript, Vite, TailwindCSS, Shadcn UI
- **Backend**: Node.js, Express, Drizzle ORM, PostgreSQL
- **Auth**: Firebase Authentication (Google sign-in only)
- **Charts**: Recharts (pie, line, bar)
- **Routing**: Wouter
- **Exports**: XLSX, jsPDF, CSV

## Architecture

- `client/src/` — React frontend
- `server/` — Express backend (routes.ts, storage.ts, db.ts)
- `shared/` — Shared schema and route types (schema.ts, routes.ts)

## Features

- **Auth**: Google sign-in via Firebase (phone login removed)
- **Multi-currency**: MMK, USD, THB, SGD, MYR, KRW, JPY, TWD, SAR, AED
- **Dashboard**: Today/weekly stats, 14-day line chart, AI insights, budget alerts, savings widgets
- **Transactions**: Add income/expense with categories, quick-add via FAB/dialog
- **History**: Filter by date/type/category, search, edit, delete; export Excel/PDF/CSV
- **Categories**: User-facing category management page with emoji icon picker (/categories)
- **Reports**: Recharts pie + bar + line charts with month/year filter
- **Budgets**: Monthly budgets per category with progress bars and alerts
- **Savings Goals**: Target amounts, progress tracking, deposit dialog, target dates
- **Recurring Transactions**: Daily/weekly/monthly/yearly, log-now button
- **Profile/Settings**: Currency selector, language switcher, dark mode toggle, notification permissions, export data shortcut, sign out
- **Dark mode**: System + manual toggle
- **Language**: English / Myanmar switcher (stored in localStorage)
- **Loading**: Skeleton placeholder UI on Dashboard, History, Reports pages
- **Offline detection**: Banner shown when device goes offline
- **PWA**: manifest.json, theme-color, mobile meta tags
- **Contact/Privacy/Terms**: Static pages
- **Footer**: Facebook, Telegram, Email support links

## Admin Panel

Accessible at `/admin/*` for users with `role = 'admin'`:
- `/admin/dashboard` — stats overview
- `/admin/users` — manage users
- `/admin/expenses` — view all transactions
- `/admin/categories` — add/delete categories
- `/admin/messages` — contact messages
- `/admin/settings` — announcements

## Firebase Setup

Required secrets:
- `VITE_FIREBASE_API_KEY`
- `VITE_FIREBASE_APP_ID`
- `VITE_FIREBASE_PROJECT_ID`

**Important**: Add the Replit domain to Firebase Console → Authentication → Authorized Domains for phone OTP to work.

## Database

Tables: `users`, `categories`, `transactions`, `budgets`, `savings_goals`, `recurring_transactions`, `messages`, `announcements`, `settings`

Run `npm run db:push` to sync schema.

Admin promotion: `UPDATE users SET role = 'admin' WHERE email = 'your@email.com';`

## Key Files

- `client/src/pages/dashboard.tsx` — Dashboard with all widgets
- `client/src/pages/budgets.tsx` — Budget management
- `client/src/pages/savings.tsx` — Savings goals
- `client/src/pages/recurring.tsx` — Recurring transactions
- `client/src/pages/history.tsx` — Transaction history with advanced filters
- `client/src/components/layout.tsx` — Nav, FAB, footer
- `client/src/components/quick-add-dialog.tsx` — Quick add modal
- `client/src/hooks/use-language.tsx` — i18n (EN/MY)
- `server/routes.ts` — All API endpoints
- `server/storage.ts` — All DB operations
- `shared/schema.ts` — Drizzle schema + types

import type { Express, Request, Response, NextFunction } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { db } from "./db";
import { users, categories } from "@shared/schema";
import { eq } from "drizzle-orm";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  const requireUser = async (req: Request, res: Response, next: NextFunction) => {
    const uid = req.headers['x-user-id'] as string;
    if (!uid) return res.status(401).json({ message: "Unauthorized" });
    const user = await storage.getUserByFirebaseUid(uid);
    if (!user) return res.status(401).json({ message: "User not found" });
    (req as any).user = user;
    next();
  };

  const requireAdmin = async (req: Request, res: Response, next: NextFunction) => {
    const uid = req.headers['x-user-id'] as string;
    if (!uid) return res.status(401).json({ message: "Unauthorized" });
    const user = await storage.getUserByFirebaseUid(uid);
    if (!user || user.role !== 'admin') return res.status(403).json({ message: "Forbidden" });
    (req as any).user = user;
    next();
  };

  app.post(api.users.sync.path, async (req, res) => {
    try {
      const input = api.users.sync.input.parse(req.body);
      const user = await storage.syncUser(input);
      res.json(user);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: err.errors[0].message });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  app.get(api.users.list.path, requireAdmin, async (req, res) => {
    const usersList = await storage.getUsers();
    res.json(usersList);
  });

  app.put(api.users.update.path, requireUser, async (req, res) => {
    try {
      const input = api.users.update.input.parse(req.body);
      const updated = await storage.updateUser(Number(req.params.id), input);
      if (!updated) return res.status(404).json({ message: "Not found" });
      res.json(updated);
    } catch (err) {
      if (err instanceof z.ZodError) res.status(400).json({ message: err.errors[0].message });
    }
  });

  app.delete(api.users.delete.path, requireAdmin, async (req, res) => {
    await storage.deleteUser(Number(req.params.id));
    res.status(204).send();
  });

  app.get(api.transactions.list.path, requireUser, async (req, res) => {
    const user = (req as any).user;
    if (user.role === 'admin' && req.query.all === 'true') {
      const allTx = await storage.getAllTransactions();
      return res.json(allTx);
    }
    const tx = await storage.getTransactions(user.id);
    res.json(tx);
  });

  app.post(api.transactions.create.path, requireUser, async (req, res) => {
    try {
      const user = (req as any).user;
      const bodySchema = api.transactions.create.input.extend({
        amount: z.coerce.string(),
        categoryId: z.coerce.number(),
      });
      const input = bodySchema.parse({...req.body, userId: user.id});
      const newTx = await storage.createTransaction(input);
      res.status(201).json(newTx);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: err.errors[0].message, field: err.errors[0].path.join('.') });
      } else {
        res.status(500).json({ message: "Error" });
      }
    }
  });

  app.put(api.transactions.update.path, requireUser, async (req, res) => {
    try {
      const user = (req as unknown as { user: { id: number; role: string } }).user;
      const id = Number(req.params.id);
      const existing = await storage.getTransactionById(id);
      if (!existing) return res.status(404).json({ message: "Not found" });
      if (existing.userId !== user.id && user.role !== 'admin') return res.status(403).json({ message: "Not your transaction" });
      const input = api.transactions.update.input.parse(req.body);
      if (input.amount) input.amount = String(input.amount);
      const updated = await storage.updateTransaction(id, input);
      if (!updated) return res.status(404).json({ message: "Not found" });
      res.json(updated);
    } catch (err) {
      if (err instanceof z.ZodError) res.status(400).json({ message: err.errors[0].message });
    }
  });

  app.delete(api.transactions.delete.path, requireUser, async (req, res) => {
    const user = (req as unknown as { user: { id: number; role: string } }).user;
    const id = Number(req.params.id);
    const existing = await storage.getTransactionById(id);
    if (!existing) return res.status(404).json({ message: "Not found" });
    if (existing.userId !== user.id && user.role !== 'admin') return res.status(403).json({ message: "Not your transaction" });
    await storage.deleteTransaction(id);
    res.status(204).send();
  });

  app.get(api.categories.list.path, requireUser, async (req, res) => {
    const user = (req as unknown as { user: { id: number; role: string } }).user;
    if (user.role === 'admin') {
      const categoriesList = await storage.getCategories();
      res.json(categoriesList);
    } else {
      const categoriesList = await storage.getCategoriesForUser(user.id);
      res.json(categoriesList);
    }
  });

  app.post(api.categories.create.path, requireUser, async (req, res) => {
    try {
      const user = (req as unknown as { user: { id: number; role: string } }).user;
      const input = api.categories.create.input.parse(req.body);
      const isDefault = user.role === 'admin' && input.isDefault === true;
      const cat = await storage.createCategory({
        ...input,
        isDefault,
        userId: isDefault ? null : user.id,
      });
      res.status(201).json(cat);
    } catch (err) {
      if (err instanceof z.ZodError) res.status(400).json({ message: err.errors[0].message });
    }
  });

  app.put(api.categories.update.path, requireUser, async (req, res) => {
    try {
      const user = (req as unknown as { user: { id: number; role: string } }).user;
      const id = Number(req.params.id);
      const existing = await storage.getCategoryById(id);
      if (!existing) return res.status(404).json({ message: "Category not found" });
      if (existing.isDefault && user.role !== 'admin') return res.status(403).json({ message: "Cannot edit system categories" });
      if (!existing.isDefault && existing.userId !== user.id && user.role !== 'admin') return res.status(403).json({ message: "Not your category" });
      const input = api.categories.update.input.parse(req.body);
      const cat = await storage.updateCategory(id, input);
      res.json(cat);
    } catch (err) {
      if (err instanceof z.ZodError) res.status(400).json({ message: err.errors[0].message });
    }
  });

  app.delete(api.categories.delete.path, requireUser, async (req, res) => {
    const user = (req as unknown as { user: { id: number; role: string } }).user;
    const id = Number(req.params.id);
    const existing = await storage.getCategoryById(id);
    if (!existing) return res.status(404).json({ message: "Category not found" });
    if (existing.isDefault && user.role !== 'admin') return res.status(403).json({ message: "Cannot delete system categories" });
    if (!existing.isDefault && existing.userId !== user.id && user.role !== 'admin') return res.status(403).json({ message: "Not your category" });
    await storage.deleteCategory(id);
    res.status(204).send();
  });

  app.get(api.budgets.list.path, requireUser, async (req, res) => {
    const user = (req as any).user;
    const userBudgets = await storage.getBudgets(user.id);
    res.json(userBudgets);
  });

  app.post(api.budgets.upsert.path, requireUser, async (req, res) => {
    try {
      const user = (req as any).user;
      const bodySchema = api.budgets.upsert.input.extend({
        amount: z.coerce.string(),
        categoryId: z.coerce.number(),
      });
      const input = bodySchema.parse({ ...req.body, userId: user.id });
      const budget = await storage.upsertBudget(input);
      res.json(budget);
    } catch (err) {
      if (err instanceof z.ZodError) res.status(400).json({ message: err.errors[0].message });
      else res.status(500).json({ message: "Error" });
    }
  });

  app.delete(api.budgets.delete.path, requireUser, async (req, res) => {
    await storage.deleteBudget(Number(req.params.id));
    res.status(204).send();
  });

  // Savings Goals
  app.get(api.savings.list.path, requireUser, async (req, res) => {
    const user = (req as any).user;
    const goals = await storage.getSavingsGoals(user.id);
    res.json(goals);
  });

  app.post(api.savings.create.path, requireUser, async (req, res) => {
    try {
      const user = (req as any).user;
      const body = { ...req.body, userId: user.id };
      if (body.targetAmount) body.targetAmount = String(body.targetAmount);
      if (body.currentAmount) body.currentAmount = String(body.currentAmount);
      if (body.targetDate) body.targetDate = new Date(body.targetDate);
      const goal = await storage.createSavingsGoal(body);
      res.status(201).json(goal);
    } catch (err) {
      if (err instanceof z.ZodError) res.status(400).json({ message: err.errors[0].message });
      else res.status(500).json({ message: "Error" });
    }
  });

  app.put(api.savings.update.path, requireUser, async (req, res) => {
    try {
      const body = { ...req.body };
      if (body.targetAmount) body.targetAmount = String(body.targetAmount);
      if (body.currentAmount) body.currentAmount = String(body.currentAmount);
      if (body.targetDate) body.targetDate = new Date(body.targetDate);
      const updated = await storage.updateSavingsGoal(Number(req.params.id), body);
      if (!updated) return res.status(404).json({ message: "Not found" });
      res.json(updated);
    } catch (err) {
      res.status(500).json({ message: "Error" });
    }
  });

  app.delete(api.savings.delete.path, requireUser, async (req, res) => {
    await storage.deleteSavingsGoal(Number(req.params.id));
    res.status(204).send();
  });

  // Recurring Transactions
  app.get(api.recurring.list.path, requireUser, async (req, res) => {
    const user = (req as any).user;
    const list = await storage.getRecurring(user.id);
    res.json(list);
  });

  app.post(api.recurring.create.path, requireUser, async (req, res) => {
    try {
      const user = (req as any).user;
      const body = { ...req.body, userId: user.id };
      if (body.amount) body.amount = String(body.amount);
      if (body.categoryId) body.categoryId = Number(body.categoryId);
      if (body.nextDue) body.nextDue = new Date(body.nextDue);
      const created = await storage.createRecurring(body);
      res.status(201).json(created);
    } catch (err) {
      if (err instanceof z.ZodError) res.status(400).json({ message: err.errors[0].message });
      else res.status(500).json({ message: "Error" });
    }
  });

  app.put(api.recurring.update.path, requireUser, async (req, res) => {
    try {
      const body = { ...req.body };
      if (body.amount) body.amount = String(body.amount);
      if (body.categoryId) body.categoryId = Number(body.categoryId);
      if (body.nextDue) body.nextDue = new Date(body.nextDue);
      const updated = await storage.updateRecurring(Number(req.params.id), body);
      res.json(updated);
    } catch (err) {
      res.status(500).json({ message: "Error" });
    }
  });

  app.delete(api.recurring.delete.path, requireUser, async (req, res) => {
    await storage.deleteRecurring(Number(req.params.id));
    res.status(204).send();
  });

  app.get(api.messages.list.path, requireAdmin, async (req, res) => {
    const msgs = await storage.getMessages();
    res.json(msgs);
  });

  app.post(api.messages.create.path, async (req, res) => {
    try {
      const input = api.messages.create.input.parse(req.body);
      const msg = await storage.createMessage(input);
      res.status(201).json(msg);
    } catch (err) {
      if (err instanceof z.ZodError) res.status(400).json({ message: err.errors[0].message });
    }
  });

  app.get(api.announcements.list.path, async (req, res) => {
    const anns = await storage.getAnnouncements();
    res.json(anns);
  });

  app.post(api.announcements.create.path, requireAdmin, async (req, res) => {
    try {
      const input = api.announcements.create.input.parse(req.body);
      const ann = await storage.createAnnouncement(input);
      res.status(201).json(ann);
    } catch (err) {
      if (err instanceof z.ZodError) res.status(400).json({ message: err.errors[0].message });
    }
  });

  app.get(api.settings.get.path, async (req, res) => {
    const setting = await storage.getSetting(req.params.key);
    if (!setting) return res.status(404).json({ message: "Not found" });
    res.json(setting);
  });

  app.post(api.settings.set.path, requireAdmin, async (req, res) => {
    try {
      const input = api.settings.set.input.parse(req.body);
      const setting = await storage.setSetting(input);
      res.json(setting);
    } catch (err) {
      if (err instanceof z.ZodError) res.status(400).json({ message: err.errors[0].message });
    }
  });

  app.get(api.admin.stats.path, requireAdmin, async (req, res) => {
    const stats = await storage.getAdminStats();
    res.json(stats);
  });

  async function seedDatabase() {
    const existingCats = await storage.getCategories();
    const existingNames = new Set(existingCats.map(c => `${c.name}:${c.type}`));

    const defaultExpenseCategories = [
      { name: "Food", icon: "🍔", type: "expense" },
      { name: "Transport", icon: "🚕", type: "expense" },
      { name: "Rent", icon: "🏠", type: "expense" },
      { name: "Bills", icon: "💡", type: "expense" },
      { name: "Shopping", icon: "🛍️", type: "expense" },
      { name: "Health", icon: "🏥", type: "expense" },
      { name: "Education", icon: "🎓", type: "expense" },
      { name: "Entertainment", icon: "🎮", type: "expense" },
      { name: "Travel", icon: "✈️", type: "expense" },
      { name: "Family", icon: "👨‍👩‍👧", type: "expense" },
      { name: "Donation", icon: "🤝", type: "expense" },
      { name: "Investment", icon: "📈", type: "expense" },
      { name: "Loan/Debt", icon: "💳", type: "expense" },
      { name: "Other", icon: "📦", type: "expense" },
    ];

    const defaultIncomeCategories = [
      { name: "Salary", icon: "💰", type: "income" },
      { name: "Business", icon: "🏢", type: "income" },
      { name: "Freelance", icon: "💻", type: "income" },
      { name: "Gift", icon: "🎁", type: "income" },
      { name: "Bonus", icon: "🎉", type: "income" },
      { name: "Investment Profit", icon: "📊", type: "income" },
      { name: "Other", icon: "📦", type: "income" },
    ];

    const allCategories = [...defaultExpenseCategories, ...defaultIncomeCategories];
    for (const cat of allCategories) {
      if (!existingNames.has(`${cat.name}:${cat.type}`)) {
        await storage.createCategory({ name: cat.name, icon: cat.icon, type: cat.type as "income" | "expense", isDefault: true });
      }
    }

    // Update old text-based icons to emoji
    const iconMap: Record<string, string> = {
      Utensils: "🍔", Car: "🚕", Wallet: "💰", Film: "🎮",
      ShoppingCart: "🛍️", Heart: "🏥", GraduationCap: "🎓",
      Plane: "✈️", Home: "🏠", Zap: "💡",
    };
    for (const existing of existingCats) {
      if (iconMap[existing.icon]) {
        await db.update(categories).set({ icon: iconMap[existing.icon] }).where(eq(categories.id, existing.id));
      }
    }

    if (existingCats.length === 0) {
      const testAdmin = await storage.syncUser({
        firebaseUid: "admin_test_uid",
        email: "admin@mydailybudget.com",
        displayName: "Admin User",
      });
      await db.update(users).set({ role: 'admin' }).where(eq(users.id, testAdmin.id));
      await storage.setSetting({ key: "ad_code", value: "" });
    }
  }

  await seedDatabase();

  return httpServer;
}

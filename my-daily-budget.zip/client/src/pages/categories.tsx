import { useState } from "react";
import { useCategories, useCreateCategory, useDeleteCategory, useUpdateCategory } from "@/hooks/use-categories";
import { useAuth } from "@/hooks/use-auth";
import { useLanguage } from "@/hooks/use-language";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Trash2, Plus, Pencil } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { Category } from "@shared/schema";

const EMOJI_LIST = [
  "🍕", "🍔", "🍜", "🍣", "🥗", "☕", "🍺", "🛒", "🏠", "💡",
  "📱", "💻", "🚗", "⛽", "🚌", "✈️", "🏥", "💊", "🎓", "📚",
  "👕", "👗", "👟", "💈", "🎬", "🎮", "🎵", "🏋️", "💰", "💵",
  "💳", "🏦", "📈", "🎁", "❤️", "👶", "🐶", "🐱", "🌿", "🔧",
  "🧹", "🧺", "📦", "🎯", "🏆", "📊", "💼", "🖨️", "📝", "🔑",
  "🏪", "🍿", "🧁", "🥤", "🎂", "🧲", "💎", "👑", "🎪", "⚽",
];

function CategoriesSkeleton() {
  return (
    <div className="space-y-6 animate-in fade-in">
      <div className="space-y-2">
        <Skeleton className="h-8 w-56" />
        <Skeleton className="h-4 w-40" />
      </div>
      <Skeleton className="h-12 w-40" />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {[1, 2].map(i => (
          <div key={i} className="glass p-6 rounded-2xl space-y-3">
            <Skeleton className="h-6 w-32" />
            {[1, 2, 3].map(j => <Skeleton key={j} className="h-14 w-full rounded-xl" />)}
          </div>
        ))}
      </div>
    </div>
  );
}

export default function Categories() {
  const { data: categories, isLoading } = useCategories();
  const { mutate: createCat, isPending: isCreating } = useCreateCategory();
  const { mutate: updateCat, isPending: isUpdating } = useUpdateCategory();
  const { mutate: deleteCat } = useDeleteCategory();
  const { user } = useAuth();
  const { t } = useLanguage();
  const { toast } = useToast();
  const isAdmin = user?.role === "admin";

  const [showAdd, setShowAdd] = useState(false);
  const [editCat, setEditCat] = useState<Category | null>(null);
  const [name, setName] = useState("");
  const [type, setType] = useState<"income" | "expense">("expense");
  const [icon, setIcon] = useState("💰");

  const openAdd = () => {
    setName(""); setIcon("💰"); setType("expense"); setEditCat(null); setShowAdd(true);
  };

  const openEdit = (cat: Category) => {
    setName(cat.name); setIcon(cat.icon || "💰"); setType(cat.type as "income" | "expense");
    setEditCat(cat); setShowAdd(true);
  };

  const handleSave = () => {
    if (!name.trim()) return;
    if (editCat) {
      updateCat({ id: editCat.id, name: name.trim(), icon }, {
        onSuccess: () => { toast({ description: "Category updated" }); setShowAdd(false); },
        onError: (err: Error) => toast({ title: "Error", description: err.message, variant: "destructive" }),
      });
    } else {
      createCat({ name: name.trim(), type, icon, isDefault: false }, {
        onSuccess: () => { toast({ description: "Category created" }); setShowAdd(false); },
        onError: (err: Error) => toast({ title: "Error", description: err.message, variant: "destructive" }),
      });
    }
  };

  if (isLoading) return <CategoriesSkeleton />;

  const expenseCats = categories?.filter(c => c.type === "expense") || [];
  const incomeCats = categories?.filter(c => c.type === "income") || [];

  return (
    <div className="space-y-6 animate-in fade-in duration-300 pb-24 md:pb-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-display font-bold">{t("categories") || "Categories"}</h1>
          <p className="text-muted-foreground text-sm mt-1">Manage your transaction categories</p>
        </div>
        <Button onClick={openAdd} className="bg-primary hover:bg-primary/90 text-white rounded-xl shadow-lg shadow-primary/20 h-10 gap-1.5" data-testid="button-add-category">
          <Plus className="w-4 h-4" /> Add
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {[
          { label: "💸 Expense Categories", items: expenseCats, color: "text-red-500" },
          { label: "💰 Income Categories", items: incomeCats, color: "text-green-500" },
        ].map(section => (
          <div key={section.label} className="glass p-5 rounded-2xl">
            <h2 className={`text-base font-bold font-display mb-4 ${section.color}`}>{section.label}</h2>
            {section.items.length === 0 ? (
              <p className="text-center text-muted-foreground text-sm py-8">No categories yet</p>
            ) : (
              <div className="space-y-2">
                {section.items.map(cat => (
                  <div key={cat.id} className="flex items-center justify-between p-3 bg-background/30 rounded-xl border border-border/50 hover:border-border transition-colors group" data-testid={`card-category-${cat.id}`}>
                    <div className="flex items-center gap-3">
                      <span className="text-2xl w-10 h-10 rounded-xl bg-muted/50 flex items-center justify-center">{cat.icon || "⚪"}</span>
                      <div>
                        <p className="font-semibold text-sm">{cat.name}</p>
                        {cat.isDefault && <p className="text-xs text-muted-foreground">System default</p>}
                      </div>
                    </div>
                    {(!cat.isDefault || isAdmin) && (
                      <div className="flex gap-1 md:opacity-0 md:group-hover:opacity-100 transition-opacity">
                        <Button variant="ghost" size="icon" onClick={() => openEdit(cat)}
                          className="text-muted-foreground hover:text-primary hover:bg-primary/10 h-8 w-8" data-testid={`button-edit-category-${cat.id}`}>
                          <Pencil className="w-4 h-4" />
                        </Button>
                        {(!cat.isDefault || isAdmin) && (
                          <Button variant="ghost" size="icon" onClick={() => {
                            if (!confirm(`Delete "${cat.name}"?`)) return;
                            deleteCat(cat.id, { onSuccess: () => toast({ description: "Category deleted" }) });
                          }} className="text-muted-foreground hover:text-red-500 hover:bg-red-500/10 h-8 w-8" data-testid={`button-delete-category-${cat.id}`}>
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>

      <Dialog open={showAdd} onOpenChange={setShowAdd}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editCat ? "Edit Category" : "Add Category"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-2">
            {!editCat && (
              <div className="grid grid-cols-2 gap-3 p-1 bg-muted/50 rounded-xl">
                <button type="button" onClick={() => setType("expense")}
                  className={cn("py-2.5 rounded-lg text-sm font-semibold transition-all", type === "expense" ? "bg-red-500 text-white shadow-md" : "text-muted-foreground")}
                  data-testid="add-cat-button-expense">
                  💸 Expense
                </button>
                <button type="button" onClick={() => setType("income")}
                  className={cn("py-2.5 rounded-lg text-sm font-semibold transition-all", type === "income" ? "bg-green-500 text-white shadow-md" : "text-muted-foreground")}
                  data-testid="add-cat-button-income">
                  💰 Income
                </button>
              </div>
            )}

            <div className="space-y-1.5">
              <Label className="text-sm">Category Name</Label>
              <Input value={name} onChange={e => setName(e.target.value)} placeholder="e.g. Food, Salary" className="h-11 bg-background/50" data-testid="add-cat-input-name" />
            </div>

            <div className="space-y-1.5">
              <Label className="text-sm">Choose Icon</Label>
              <div className="flex items-center gap-3 mb-2">
                <span className="text-3xl w-12 h-12 rounded-xl bg-muted/50 flex items-center justify-center border-2 border-primary/30">{icon}</span>
                <p className="text-sm text-muted-foreground">Selected icon</p>
              </div>
              <div className="grid grid-cols-10 gap-1.5 max-h-36 overflow-y-auto p-1">
                {EMOJI_LIST.map(emoji => (
                  <button key={emoji} type="button" onClick={() => setIcon(emoji)}
                    className={cn("w-9 h-9 rounded-lg flex items-center justify-center text-lg hover:bg-muted/60 transition-colors",
                      icon === emoji ? "bg-primary/20 ring-2 ring-primary" : ""
                    )} data-testid={`add-cat-emoji-${emoji}`}>
                    {emoji}
                  </button>
                ))}
              </div>
            </div>

            <Button onClick={handleSave} disabled={isCreating || isUpdating || !name.trim()} className="w-full h-11 font-semibold rounded-xl bg-primary hover:bg-primary/90 text-white" data-testid="add-cat-button-save">
              {(isCreating || isUpdating) ? "Saving..." : editCat ? "Save Changes" : "Add Category"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

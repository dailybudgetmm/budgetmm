import { useAuth } from "@/hooks/use-auth";
import { useLanguage } from "@/hooks/use-language";
import { useTransactions } from "@/hooks/use-transactions";
import { useBudgets } from "@/hooks/use-budgets";
import { useSavingsGoals } from "@/hooks/use-savings";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import {
  Plus, Wallet, TrendingUp, Target, Zap, CalendarDays, Trophy,
  ArrowUpIcon, ArrowDownIcon, PiggyBank, RefreshCw, AlertTriangle
} from "lucide-react";
import {
  format, startOfMonth, endOfMonth, isWithinInterval,
  startOfWeek, endOfWeek, startOfDay, endOfDay,
  subDays, eachDayOfInterval, differenceInDays
} from "date-fns";
import {
  PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend,
  LineChart, Line, XAxis, YAxis, CartesianGrid
} from "recharts";
import { QuickAddDialog } from "@/components/quick-add-dialog";
import { useState } from "react";

const COLORS = ['#8b5cf6','#d946ef','#0ea5e9','#eab308','#22c55e','#ef4444','#f97316','#06b6d4','#84cc16','#fb923c'];

export default function Dashboard() {
  const { user } = useAuth();
  const { t } = useLanguage();
  const { data: transactions, isLoading } = useTransactions();
  const { data: budgets } = useBudgets();
  const { data: savingsGoals } = useSavingsGoals();
  const [showQuickAdd, setShowQuickAdd] = useState(false);

  if (isLoading) return <DashboardSkeleton />;

  const currency = user?.defaultCurrency || "MMK";
  const all = transactions?.filter(tx => tx.currency === currency) || [];
  const now = new Date();

  const thisMonth = all.filter(tx => isWithinInterval(new Date(tx.date), { start: startOfMonth(now), end: endOfMonth(now) }));
  const thisWeek  = all.filter(tx => isWithinInterval(new Date(tx.date), { start: startOfWeek(now, { weekStartsOn: 1 }), end: endOfWeek(now, { weekStartsOn: 1 }) }));
  const todayTxs  = all.filter(tx => isWithinInterval(new Date(tx.date), { start: startOfDay(now), end: endOfDay(now) }));

  const sum = (txs: typeof all, type: string) => txs.filter(tx => tx.type === type).reduce((s, tx) => s + Number(tx.amount), 0);

  const totalIncome  = sum(all, 'income');
  const totalExpense = sum(all, 'expense');
  const totalBalance = totalIncome - totalExpense;
  const monthlyIncome  = sum(thisMonth, 'income');
  const monthlyExpense = sum(thisMonth, 'expense');
  const monthlyBalance = monthlyIncome - monthlyExpense;
  const weeklyExpense  = sum(thisWeek, 'expense');
  const todayExpense   = sum(todayTxs, 'expense');
  const savingsRate    = monthlyIncome > 0 ? Math.round((monthlyBalance / monthlyIncome) * 100) : 0;

  // Category spending for pie
  const categoryTotals = thisMonth.filter(tx => tx.type === 'expense').reduce((acc, tx) => {
    const name = `${tx.category?.icon || ''} ${tx.category?.name || 'Other'}`;
    acc[name] = (acc[name] || 0) + Number(tx.amount);
    return acc;
  }, {} as Record<string, number>);
  const pieData = Object.entries(categoryTotals).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value).slice(0, 8);
  const topCategory = pieData[0];

  // 14-day line chart
  const last14 = eachDayOfInterval({ start: subDays(now, 13), end: now });
  const lineData = last14.map(day => {
    const dayTx = all.filter(tx => isWithinInterval(new Date(tx.date), { start: startOfDay(day), end: endOfDay(day) }));
    return { date: format(day, 'MMM d'), expense: sum(dayTx, 'expense'), income: sum(dayTx, 'income') };
  });

  // Budget alerts
  const myBudgets = budgets?.filter(b => b.currency === currency) || [];
  const budgetAlerts = myBudgets.map(b => {
    const spent = sum(thisMonth.filter(tx => tx.type === 'expense' && tx.categoryId === b.categoryId), 'expense');
    const pct = (spent / Number(b.amount)) * 100;
    return { ...b, spent, pct };
  }).filter(b => b.pct >= 80);

  // Last-week comparison
  const lastWeekTx = all.filter(tx => isWithinInterval(new Date(tx.date), {
    start: startOfWeek(subDays(now, 7), { weekStartsOn: 1 }),
    end: endOfWeek(subDays(now, 7), { weekStartsOn: 1 })
  }));
  const lastWeekExp = sum(lastWeekTx, 'expense');
  const weekDiff = lastWeekExp > 0 ? Math.round(((weeklyExpense - lastWeekExp) / lastWeekExp) * 100) : null;

  // Recent 5 transactions
  const recent = [...(transactions || [])].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).slice(0, 5);

  const mySavings = savingsGoals?.filter(g => g.currency === currency) || [];

  const fmt = (n: number) => n.toLocaleString();

  return (
    <div className="space-y-6 animate-in slide-in-from-bottom-4 duration-500 pb-24 md:pb-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl sm:text-3xl font-display font-bold">{t("dashboard")}</h1>
          <p className="text-muted-foreground text-sm">{t("welcomeBack")}, {user?.displayName?.split(' ')[0] || 'there'} 👋</p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            className="hidden sm:flex items-center gap-1.5 rounded-xl border-white/10 h-9"
            onClick={() => setShowQuickAdd(true)}
            data-testid="button-quick-add"
          >
            <Zap className="w-3.5 h-3.5 text-primary" /> Quick Add
          </Button>
          <Link href="/add">
            <Button className="bg-primary hover:bg-primary/90 text-white rounded-xl shadow-lg shadow-primary/20 h-10 px-4" data-testid="button-add-transaction">
              <Plus className="w-4 h-4 mr-1" /> {t("addRecord")}
            </Button>
          </Link>
        </div>
      </div>

      {/* Budget alerts */}
      {budgetAlerts.length > 0 && (
        <div className="space-y-2">
          {budgetAlerts.slice(0, 2).map(b => (
            <div key={b.id} className={`rounded-xl px-4 py-3 flex items-center gap-3 text-sm ${b.pct >= 100 ? 'bg-red-500/15 border border-red-500/30' : 'bg-amber-500/15 border border-amber-500/30'}`}>
              <AlertTriangle className={`w-4 h-4 shrink-0 ${b.pct >= 100 ? 'text-red-500' : 'text-amber-500'}`} />
              <p className="flex-1 min-w-0 text-sm">
                <span className={`font-semibold ${b.pct >= 100 ? 'text-red-500' : 'text-amber-500'}`}>
                  {b.pct >= 100 ? 'Budget exceeded' : 'Approaching limit'} —
                </span>{" "}
                {b.category?.name}: {fmt(b.spent)} / {fmt(Number(b.amount))} {currency} ({Math.round(b.pct)}%)
              </p>
              <Link href="/budgets"><Button variant="ghost" size="sm" className="shrink-0 h-7 text-xs">View</Button></Link>
            </div>
          ))}
        </div>
      )}

      {/* Primary stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <MiniCard icon={<Wallet className="w-4 h-4 text-primary" />} label="Total Balance" value={`${fmt(totalBalance)} ${currency}`} valueClass={totalBalance >= 0 ? '' : 'text-red-500'} accent="bg-primary/10" />
        <MiniCard icon={<ArrowUpIcon className="w-4 h-4 text-green-500" />} label="Month Income" value={`+${fmt(monthlyIncome)}`} valueClass="text-green-500" accent="bg-green-500/10" />
        <MiniCard icon={<ArrowDownIcon className="w-4 h-4 text-red-500" />} label="Month Expense" value={`-${fmt(monthlyExpense)}`} valueClass="text-red-500" accent="bg-red-500/10" />
        <MiniCard icon={<TrendingUp className="w-4 h-4 text-blue-500" />} label="Net Savings" value={(monthlyBalance >= 0 ? '+' : '') + fmt(monthlyBalance)} valueClass={monthlyBalance >= 0 ? 'text-blue-500' : 'text-red-500'} accent="bg-blue-500/10" />
      </div>

      {/* Secondary stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <MiniCard icon={<CalendarDays className="w-4 h-4 text-purple-500" />} label="Today" value={`-${fmt(todayExpense)}`} valueClass="text-sm text-muted-foreground" accent="bg-purple-500/10" small />
        <MiniCard icon={<CalendarDays className="w-4 h-4 text-indigo-500" />} label="This Week" value={`-${fmt(weeklyExpense)}`} valueClass="text-sm text-muted-foreground" accent="bg-indigo-500/10" small />
        <MiniCard icon={<Trophy className="w-4 h-4 text-amber-500" />} label="Top Spend" value={topCategory?.name || '—'} valueClass="text-sm truncate" accent="bg-amber-500/10" small />
        <MiniCard icon={<Target className="w-4 h-4 text-emerald-500" />} label="Savings Rate" value={`${savingsRate}%`} valueClass={`text-sm ${savingsRate >= 20 ? 'text-emerald-500' : 'text-amber-500'}`} accent="bg-emerald-500/10" small />
      </div>

      {/* Insight banner */}
      {weekDiff !== null && (
        <div className={`glass rounded-xl p-4 flex items-start gap-3 border ${weekDiff > 0 ? 'border-red-500/20' : 'border-green-500/20'}`}>
          <Zap className={`w-5 h-5 mt-0.5 shrink-0 ${weekDiff > 0 ? 'text-red-500' : 'text-green-500'}`} />
          <div>
            <p className="text-sm font-semibold">AI Spending Insight</p>
            <p className="text-sm text-muted-foreground">
              {weekDiff > 0
                ? `You spent ${weekDiff}% more than last week. ${topCategory ? `Most spent on ${topCategory.name}.` : ''}`
                : `You spent ${Math.abs(weekDiff)}% less than last week. Great job! 🎉`}
              {monthlyBalance > 0 ? ` You're saving ${fmt(monthlyBalance)} ${currency} this month.` : ''}
            </p>
          </div>
        </div>
      )}

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Pie chart */}
        <div className="glass rounded-2xl p-5">
          <h2 className="text-base font-bold font-display mb-4">{t("spendingByCategory")}</h2>
          {pieData.length === 0 ? (
            <div className="h-52 flex items-center justify-center text-center text-muted-foreground text-sm">
              <div><div className="text-4xl mb-2">🍩</div>No expenses this month</div>
            </div>
          ) : (
            <div className="h-52">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={pieData} cx="50%" cy="50%" innerRadius={52} outerRadius={85} paddingAngle={3} dataKey="value">
                    {pieData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                  </Pie>
                  <Tooltip formatter={(v: number) => [`${v.toLocaleString()} ${currency}`, '']} contentStyle={{ borderRadius: '0.75rem', border: 'none', background: 'hsl(var(--card))' }} />
                  <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: '11px' }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>

        {/* Line chart */}
        <div className="glass rounded-2xl p-5">
          <h2 className="text-base font-bold font-display mb-4">14-Day Spending Trend</h2>
          <div className="h-52">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={lineData} margin={{ top: 5, right: 5, left: -28, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="date" tick={{ fontSize: 9 }} tickLine={false} axisLine={false} tickFormatter={v => v.split(' ')[1]} />
                <YAxis tick={{ fontSize: 9 }} tickLine={false} axisLine={false} tickFormatter={v => v >= 1000 ? `${(v/1000).toFixed(0)}k` : v} />
                <Tooltip formatter={(v: number) => [`${v.toLocaleString()} ${currency}`, '']} contentStyle={{ borderRadius: '0.75rem', border: 'none', background: 'hsl(var(--card))' }} />
                <Line type="monotone" dataKey="expense" stroke="#ef4444" strokeWidth={2} dot={false} name="Expense" />
                <Line type="monotone" dataKey="income" stroke="#22c55e" strokeWidth={2} dot={false} name="Income" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Budget progress */}
      {myBudgets.length > 0 && (
        <div className="glass rounded-2xl p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-base font-bold font-display">Budget Progress</h2>
            <Link href="/budgets"><Button variant="ghost" className="text-primary p-0 h-auto text-sm">Manage</Button></Link>
          </div>
          <div className="space-y-3">
            {myBudgets.slice(0, 5).map(b => {
              const spent = sum(thisMonth.filter(tx => tx.type === 'expense' && tx.categoryId === b.categoryId), 'expense');
              const pct = Math.min((spent / Number(b.amount)) * 100, 100);
              const isExceeded = pct >= 100;
              const isWarning = pct >= 80 && !isExceeded;
              return (
                <div key={b.id}>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="flex items-center gap-1.5">{b.category?.icon} {b.category?.name}</span>
                    <span className="text-muted-foreground">{fmt(spent)} / {fmt(Number(b.amount))} {currency}</span>
                  </div>
                  <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                    <div className={`h-full rounded-full transition-all duration-500 ${isExceeded ? 'bg-red-500' : isWarning ? 'bg-amber-500' : 'bg-primary'}`} style={{ width: `${pct}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Savings goals */}
      {mySavings.length > 0 && (
        <div className="glass rounded-2xl p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-base font-bold font-display">🎯 Savings Goals</h2>
            <Link href="/savings"><Button variant="ghost" className="text-primary p-0 h-auto text-sm">Manage</Button></Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {mySavings.slice(0, 4).map(goal => {
              const pct = Math.min((Number(goal.currentAmount) / Number(goal.targetAmount)) * 100, 100);
              const remaining = Number(goal.targetAmount) - Number(goal.currentAmount);
              const daysLeft = goal.targetDate ? differenceInDays(new Date(goal.targetDate), now) : null;
              return (
                <div key={goal.id} className="bg-white/5 rounded-xl p-4 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-xl">{goal.icon}</span>
                      <span className="font-semibold text-sm">{goal.name}</span>
                    </div>
                    {pct >= 100 && <span className="text-xs bg-green-500/20 text-green-500 px-2 py-0.5 rounded-full">Done! 🎉</span>}
                  </div>
                  <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-primary to-accent rounded-full transition-all duration-500" style={{ width: `${pct}%` }} />
                  </div>
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>{fmt(Number(goal.currentAmount))} / {fmt(Number(goal.targetAmount))} {currency}</span>
                    <span>{daysLeft !== null ? (daysLeft > 0 ? `${daysLeft}d left` : 'Overdue') : `${Math.round(pct)}%`}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Recent transactions */}
      <div className="glass rounded-2xl p-5">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-base font-bold font-display">{t("recentTransactions")}</h2>
          <Link href="/history"><Button variant="ghost" className="text-primary p-0 h-auto text-sm">{t("viewAll")}</Button></Link>
        </div>
        {recent.length === 0 ? (
          <div className="text-center py-10 space-y-3">
            <div className="text-4xl">💸</div>
            <p className="text-muted-foreground text-sm">{t("noTransactions")}</p>
            <Link href="/add"><Button className="bg-primary text-white rounded-xl" size="sm"><Plus className="w-3.5 h-3.5 mr-1" /> Add first record</Button></Link>
          </div>
        ) : (
          <div className="space-y-1">
            {recent.map(tx => (
              <div key={tx.id} className="flex items-center justify-between p-3 rounded-xl hover:bg-white/5 transition-colors group">
                <div className="flex items-center gap-3 min-w-0">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-lg shrink-0 ${tx.type === 'income' ? 'bg-green-500/10' : 'bg-red-500/10'}`}>
                    {tx.category?.icon || (tx.type === 'income' ? '💰' : '💸')}
                  </div>
                  <div className="min-w-0">
                    <p className="font-semibold text-sm truncate">{tx.description || tx.category?.name}</p>
                    <p className="text-xs text-muted-foreground">{format(new Date(tx.date), 'MMM d, yyyy')}</p>
                  </div>
                </div>
                <div className={`font-bold font-display text-sm shrink-0 ml-2 ${tx.type === 'income' ? 'text-green-500' : 'text-red-500'}`}>
                  {tx.type === 'income' ? '+' : '-'}{Number(tx.amount).toLocaleString()} <span className="text-xs font-normal opacity-60">{tx.currency}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <QuickAddDialog open={showQuickAdd} onClose={() => setShowQuickAdd(false)} />
    </div>
  );
}

function MiniCard({ icon, label, value, valueClass, accent, small }: {
  icon: React.ReactNode; label: string; value: string;
  valueClass?: string; accent: string; small?: boolean;
}) {
  return (
    <div className="glass p-4 rounded-2xl space-y-2">
      <div className={`w-8 h-8 rounded-lg ${accent} flex items-center justify-center`}>{icon}</div>
      <div>
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className={`font-bold font-display truncate ${small ? 'text-sm' : 'text-lg'} ${valueClass}`}>{value}</p>
      </div>
    </div>
  );
}

function DashboardSkeleton() {
  return (
    <div className="space-y-6 animate-in slide-in-from-bottom-4 duration-500 pb-24 md:pb-6">
      <div className="flex items-center justify-between">
        <div className="space-y-2">
          <Skeleton className="h-8 w-40" />
          <Skeleton className="h-4 w-56" />
        </div>
        <div className="flex gap-2">
          <Skeleton className="h-9 w-24 hidden sm:block rounded-xl" />
          <Skeleton className="h-10 w-32 rounded-xl" />
        </div>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[1,2,3,4].map(i => (
          <div key={i} className="glass p-4 rounded-2xl space-y-2">
            <Skeleton className="w-8 h-8 rounded-lg" />
            <Skeleton className="h-3 w-16" />
            <Skeleton className="h-6 w-24" />
          </div>
        ))}
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[1,2,3,4].map(i => (
          <div key={i} className="glass p-4 rounded-2xl space-y-2">
            <Skeleton className="w-8 h-8 rounded-lg" />
            <Skeleton className="h-3 w-14" />
            <Skeleton className="h-5 w-20" />
          </div>
        ))}
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="glass rounded-2xl p-5 space-y-4">
          <Skeleton className="h-5 w-40" />
          <Skeleton className="h-52 w-full rounded-xl" />
        </div>
        <div className="glass rounded-2xl p-5 space-y-4">
          <Skeleton className="h-5 w-44" />
          <Skeleton className="h-52 w-full rounded-xl" />
        </div>
      </div>
      <div className="glass rounded-2xl p-5 space-y-3">
        <Skeleton className="h-5 w-40" />
        {[1,2,3,4,5].map(i => (
          <div key={i} className="flex items-center justify-between p-3 rounded-xl">
            <div className="flex items-center gap-3">
              <Skeleton className="w-10 h-10 rounded-xl" />
              <div className="space-y-1.5">
                <Skeleton className="h-4 w-28" />
                <Skeleton className="h-3 w-20" />
              </div>
            </div>
            <Skeleton className="h-4 w-24" />
          </div>
        ))}
      </div>
    </div>
  );
}

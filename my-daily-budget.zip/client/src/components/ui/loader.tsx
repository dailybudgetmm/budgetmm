import { Loader2 } from "lucide-react";

export function Loader({ size = 24 }: { size?: number }) {
  return (
    <div className="flex justify-center items-center p-8">
      <Loader2 className="animate-spin text-primary" size={size} />
    </div>
  );
}
